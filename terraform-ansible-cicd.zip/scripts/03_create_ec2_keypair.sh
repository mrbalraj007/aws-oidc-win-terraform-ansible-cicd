#!/bin/bash
# scripts/03_create_ec2_keypair.sh
# ---------------------------------
# Creates an EC2 Key Pair and saves the private key locally.
# The key name is then added as a GitHub Actions secret.
#
# Usage:
#   chmod +x scripts/03_create_ec2_keypair.sh
#   ./scripts/03_create_ec2_keypair.sh

set -euo pipefail

# ---- CONFIGURATION ---- Edit these ----
AWS_REGION="ap-southeast-2"
KEY_NAME="terraform-ansible-demo-key"
KEY_DIR="$HOME/.ssh"

echo "==> Creating EC2 Key Pair: $KEY_NAME"
echo "==> Region: $AWS_REGION"

mkdir -p "$KEY_DIR"
KEY_FILE="$KEY_DIR/${KEY_NAME}.pem"

# Check if key already exists in AWS
EXISTING=$(aws ec2 describe-key-pairs \
  --key-names "$KEY_NAME" \
  --region "$AWS_REGION" \
  --query "KeyPairs[0].KeyName" \
  --output text 2>/dev/null || echo "None")

if [ "$EXISTING" != "None" ] && [ "$EXISTING" != "" ]; then
  echo "   Key pair '$KEY_NAME' already exists in AWS."
  echo "   If you need the private key, delete and recreate it."
else
  # Create and save
  aws ec2 create-key-pair \
    --key-name "$KEY_NAME" \
    --query "KeyMaterial" \
    --output text \
    --region "$AWS_REGION" > "$KEY_FILE"

  chmod 600 "$KEY_FILE"
  echo "   Private key saved to: $KEY_FILE"
fi

echo ""
echo "=============================================="
echo "Key Pair setup complete!"
echo "Add these secrets to GitHub Actions:"
echo "  TF_VAR_key_name = $KEY_NAME"
echo ""
echo "If you need to decode the Windows password:"
echo "  aws ec2 get-password-data \\"
echo "    --instance-id <INSTANCE_ID> \\"
echo "    --priv-launch-key $KEY_FILE \\"
echo "    --region $AWS_REGION"
echo "=============================================="
