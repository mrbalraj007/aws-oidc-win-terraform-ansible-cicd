#!/bin/bash
# scripts/02_setup_s3_backend.sh
# --------------------------------
# Creates an S3 bucket + DynamoDB table for Terraform remote state.
#
# Usage:
#   chmod +x scripts/02_setup_s3_backend.sh
#   ./scripts/02_setup_s3_backend.sh

set -euo pipefail

# ---- CONFIGURATION ---- Edit these ----
AWS_REGION="ap-southeast-2"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
BUCKET_NAME="tfstate-${ACCOUNT_ID}-${AWS_REGION}"
DYNAMODB_TABLE="terraform-lock"

echo "==> Account    : $ACCOUNT_ID"
echo "==> Bucket     : $BUCKET_NAME"
echo "==> DynamoDB   : $DYNAMODB_TABLE"
echo "==> Region     : $AWS_REGION"

# ---- Create S3 Bucket ----
echo ""
echo "==> Creating S3 bucket..."
if [ "$AWS_REGION" = "us-east-1" ]; then
  aws s3api create-bucket \
    --bucket "$BUCKET_NAME" \
    --region "$AWS_REGION"
else
  aws s3api create-bucket \
    --bucket "$BUCKET_NAME" \
    --region "$AWS_REGION" \
    --create-bucket-configuration LocationConstraint="$AWS_REGION"
fi

# Enable versioning
aws s3api put-bucket-versioning \
  --bucket "$BUCKET_NAME" \
  --versioning-configuration Status=Enabled

# Enable encryption
aws s3api put-bucket-encryption \
  --bucket "$BUCKET_NAME" \
  --server-side-encryption-configuration '{
    "Rules": [{
      "ApplyServerSideEncryptionByDefault": {
        "SSEAlgorithm": "AES256"
      }
    }]
  }'

# Block public access
aws s3api put-public-access-block \
  --bucket "$BUCKET_NAME" \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

echo "   S3 bucket ready: $BUCKET_NAME"

# ---- Create DynamoDB Table ----
echo ""
echo "==> Creating DynamoDB lock table..."
aws dynamodb create-table \
  --table-name "$DYNAMODB_TABLE" \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region "$AWS_REGION" 2>/dev/null \
  || echo "   (Table may already exist – skipping)"

echo "   DynamoDB table ready: $DYNAMODB_TABLE"

echo ""
echo "=============================================="
echo "S3 backend setup complete!"
echo "Add these secrets to GitHub Actions:"
echo "  TF_VAR_tf_state_bucket = $BUCKET_NAME"
echo "  TF_VAR_tf_lock_table   = $DYNAMODB_TABLE"
echo "=============================================="
